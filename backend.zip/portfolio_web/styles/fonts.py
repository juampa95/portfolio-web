font_weights = {
    "bold": "800",
    "heading": "700",
    "subheading": "600",
    "section": "600",
}