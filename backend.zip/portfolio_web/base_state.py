import reflex as rx


class State(rx.State):
    """The base state."""